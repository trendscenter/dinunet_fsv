from .remote import COINNRemote
from .local import COINNLocal
from .reducer import COINNReducer
from .learner import COINNLearner
